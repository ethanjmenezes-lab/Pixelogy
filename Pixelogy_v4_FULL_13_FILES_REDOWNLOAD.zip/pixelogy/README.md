# Pixelogy — cleanup, ShoreDex & Battle Bots

**Scan litter. Collect pixel art. Gear up your crab. Practice battle now; challenge friends when real PvP is ready.**

- **Version:** v4 — cross-chat alignment: React/Vite workflow, discovery-first collection, optional self-reported cleanup points, Figma and Battle Bots.
- **Status:** design / implementation specifications, **not a built game or a Figma file**.
- **Context:** solo, beach-themed HowdyHack 2026 project. Confirm the event's current submission/originality requirements before using code or assets.
- **Inspirations:** the approachable creature-collection and turn-based strategy loops associated with Pokémon and Prodigy. Create original crab, cards, moves, artwork, sounds and UI; do not reuse protected characters or assets.

## The two linked gameplay loops

**DISCOVER:** photograph safe litter → consent to Gemini identification (or manual fallback) → choose/correct focused crop → pixelize object → save rarity card and equipment to ShoreDex. A scan is a *discovery*, not evidence that the object was removed.

**CLEANUP (separate, optional self-report):** after discovering an eligible item, the player may tap `I safely disposed of this litter` now or later. Only this one-time confirmation awards **+10 cleanup XP** (+5 first confirmed cleanup in a new category); only opted-in server-recorded cleanup events may appear on the weekly cleanup XP leaderboard. Without confirmation, **card and gear are still available**, but cleanup XP is zero.

**BATTLE BOTS:** visit Crab Workshop → equip *one owned, discovered item per gear slot* on an original **red crab** → preview appearance/stats → battle CPU in a short turn-based practice match → optionally challenge a **real** second player by invite code if online PvP has been implemented and tested.

Your safe trash discoveries are personalized collectible cards **and** craft-free equipment (no physical cleanup verification required to unlock gear). Examples: **plastic bag → Bag Helm (head)**, **magazine → Magazine Mail (shell)**, **bottle caps → Cap Boots (feet)**, **safely handled intact bottle → Bottle Blade (weapon)**. Glass or sharp hazards must never be pursued for rewards; broken/unknown glass is blocked. A safe discovery grants an item but not an arbitrary combat upgrade based on dangerousness.

**Important distinction:** Rarity is cosmetic; **gear type** has standardized, small stat modifiers. More dangerous, expensive, rare or physically hard-to-retrieve items never get stronger bonuses. Collecting more gear increases customization choices, not unbounded stacking.

## Start here

1. [`AGENTS.md`](AGENTS.md) — authoritative instructions for Codex.
2. [`PROJECT_PLAN.md`](PROJECT_PLAN.md) — features, scope, priorities and milestones.
3. [`docs/FIGMA_UI_WORKFLOW.md`](docs/FIGMA_UI_WORKFLOW.md) — design tokens, screens, Figma → Codex handoff.
4. [`docs/UX_AND_GAMEPLAY.md`](docs/UX_AND_GAMEPLAY.md) — user experience and red-crab visual composition.
5. [`docs/GEAR_CATALOG.md`](docs/GEAR_CATALOG.md) — exact trash→equipment taxonomy and slot rules.
6. [`docs/BATTLE_SYSTEM.md`](docs/BATTLE_SYSTEM.md) — deterministic battles, CPU AI, online PvP contract.
7. [`docs/TECHNICAL_SPEC.md`](docs/TECHNICAL_SPEC.md) — architecture, models, endpoints, storage, privacy and security.
8. [`docs/IMPLEMENTATION_TASKS.md`](docs/IMPLEMENTATION_TASKS.md) — incremental acceptance checklist.
9. [`docs/CODEX_PROMPTS.md`](docs/CODEX_PROMPTS.md) — ready-to-paste prompts.
10. [`docs/DEMO_AND_TESTING.md`](docs/DEMO_AND_TESTING.md) — actual demo checks and honest disclosures.
11. [`docs/CROSS_CHAT_ALIGNMENT.md`](docs/CROSS_CHAT_ALIGNMENT.md) — reconciled decisions and precedence.
12. [`docs/REVISION_NOTES.md`](docs/REVISION_NOTES.md) — changes and decisions.

## Product surface

| Route | Purpose | Availability target |
|---|---|---|
| `/` | Pixel-beach home and entry to both game loops | MVP |
| `/scan` | Capture, identify, crop, pixelize, collect; optional cleanup confirmation | MVP |
| `/collection` | ShoreDex cards + equipment-capable inventory | MVP |
| `/workshop` | Red crab with equipment slots, inventory, live stat preview | MVP |
| `/battle/practice` | Genuine local deterministic turn-based fight vs CPU | MVP battle vertical slice |
| `/leaderboard` | Opt-in **real** weekly cleanup-XP leaderboard | Online target |
| `/battle/challenge` + `/battle/[id]` | Invite a real player and resolve authorized PvP turns | Stretch: only expose when real backend works |

### Recommended stack

React + Vite + TypeScript + Tailwind CSS + React Router; Canvas for object-focused pixel art and composited crab sprite; IndexedDB for photos-as-pixel-art + inventory; **Google Gemini via a Vercel serverless `/api/analyze` route** for recognition and localization; **Supabase** only for actual online features (anonymous identity, weekly cleanup board and optional battle sessions). Figma is the design source of truth, with component styles translated into tokens and React/Tailwind. **No connected Figma file has yet been provided**; use the workflow doc to create one.

### External setup

```dotenv
# server-side only
GEMINI_API_KEY=
GEMINI_MODEL=
# online-only features; add if enabled
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
SUPABASE_SERVICE_ROLE_KEY= # server functions only, optional; never VITE_
```

Never commit `.env.local`. Do not purchase services or assets without permission. If no Gemini credentials exist, label the flow **Manual mode**; if no Supabase connection exists, show **Live leaderboard unavailable** and hide/disable PvP challenge creation. A CPU match is always labeled **Practice vs CPU**, never another person.

### Setup order and developer commands (once app exists)

1. Create GitHub repository; configure Vercel project (HTTPS, SPA rewrite, Functions), Supabase project with RLS and public publishable key, and Gemini API key kept server-side. Do not expose server secrets.
2. Create Figma foundation, mobile frames, Workshop and battle assets; share specific frame URLs with Codex.
3. Codex implements React/Vite app using written specs and actual Figma frames when available. Manual scan and local practice battle must work without online services.
4. `npm run dev` runs the **Vite front-end only**; use `vercel dev` (or a deliberately configured local proxy/function emulator) to exercise `/api/analyze` and other Vercel functions locally. Do not imply Gemini works under bare Vite.
5. Verify `npm run build`, tests, HTTPS deployment, env configuration, and two-account tests for any public leaderboard/PvP before making launch claims.

Vite embeds `VITE_*` variables into client code: they may hold a **public** Supabase URL/publishable key, but **never** Gemini secrets, service role credentials, or private tokens.

### Design handoff to Codex

Figma's official remote MCP server is available for Codex. In the Codex app, install/connect its Figma plugin; in Codex CLI, official setup is:

```bash
codex mcp add figma --url https://mcp.figma.com/mcp
```

Then authorize Figma and give Codex the real design file/frame links (not supplied in this package). When Figma is not connected, Codex can follow the token/layout spec, but should **not claim pixel-perfect implementation of nonexistent Figma frames**. See [`docs/FIGMA_UI_WORKFLOW.md`](docs/FIGMA_UI_WORKFLOW.md).

## Project status and rules

This ZIP contains planning Markdown, **not** application code, a connected Supabase instance, deployed website or actual Figma frames. Work within the event's current rules and label working vs planned features in the demo. The optional cleanup confirmation is self-reported, not proof of litter disposal; the game must never encourage handling dangerous items.

Official design reference: [Figma's Codex MCP setup](https://help.figma.com/hc/en-us/articles/39888629089175-Codex-and-Figma-Set-up-the-MCP-server). Other sources and implementation details are linked in the technical documents.
