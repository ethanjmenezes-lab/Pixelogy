# Revision history and key decisions

## v4 — October 24, 2026 — alignment with other Howdy Hack conversation

- Chose **React + Vite + TypeScript + Tailwind + React Router**, matching the other conversation’s recommended implementation path. Server-only Gemini requests now use Vercel `api/` functions; Vite local dev limitations and public `VITE_` env rules are stated explicitly.
- Separated **safe discovery** (card, pixel artwork, gear saved immediately, zero cleanup XP) from **optional self-reported cleanup** (once per card, +10 XP and +5 for first confirmed category). This resolves the other chat’s warning that photographing litter does not prove it was picked up.
- Retained real weekly self-reported cleanup XP leaderboard, opt-in public profiles, and no fake scores, plus core original red crab, five equipment slots, and genuine CPU practice battles. Online PvP remains a validated stretch goal.
- Added GitHub/Vercel/Supabase/Gemini/Figma handoff setup order and `CROSS_CHAT_ALIGNMENT.md` to explain differences; no external accounts, designs or code were actually created.
- The v3 details below are historical; v4 rules take precedence when they differ.

## v3 — October 24, 2026 — Figma + Battle Bots

Added:
- Figma-first design-system and Codex MCP handoff guide (`FIGMA_UI_WORKFLOW.md`). No Figma canvas/file is included or claimed.
- Connected second game loop: every eligible saved trash card can supply standardized **wearable gear for the red crab**.
- `GEAR_CATALOG.md`: five equipment slots, intuitive per-item mappings (bag helmet, magazine body armor, bottle weapon, can shield, bottle-cap boots), fixed stats, subtype precedence and hazard safeguards.
- `BATTLE_SYSTEM.md`: actual short **turn-based Practice vs CPU**, authoritative damage/Guard/Tidal Slam rules, fair stats independent of rarity, and optional secure real-player invite PvP.
- Workshop + practice battle routes and Figma frame names, data models, acceptance tests, stage prompts and revised demo.

Changed:
- Core pitch is now **Scan → Collect → Equip → Battle**, not just a ShoreDex with leaderboards.
- Original nine cleanup category keys retained for easy compatibility; magazine is a paper/cardboard subtype and safe bottle example a constrained `other_litter` subtype.
- XP still +10 safe cleanup and +5 new category; cosmetic rarity still 60/27/10/3. Battle wins are separate from cleanup XP.
- Existing real weekly leaderboard remains an integration target; **online 1v1** is a separately documented stretch feature and never simulated as humans.
- MVP priority shifts to completing a true cleanup→gear→CPU experience before risky online PvP work.

## v2 — original scanned-litter vision

Retained: Gemini-first recognition/localization, object-centered crop/mask instead of whole photo, safety confirmation, rarity-tiered ShoreDex, IndexedDB persistence, real opt-in weekly cleanup-XP leaderboard with honest fallback, and privacy/security guardrails.

## Decisions to revisit when implementation begins

1. Whether an actual Figma file/frame will be connected before Codex builds screens (none supplied yet).
2. Whether available Gemini model reliably returns masks; manual crop is always required.
3. Whether the tournament/demo needs real PvP; current recommendation is CPU MVP + real PvP stretch.
4. Whether **intact bottle** gear should be limited to a virtual illustrative sprite; MVP safest path is plastic bottle `bottle_blade` and no glass encouragement.
5. Need real server-backed inventory ownership before online PvP loadouts can be trusted. Local-only inventory must not be accepted as authenticated PvP power.

## No implementation claims

These files are product and technical **specifications only**. No Figma file, codebase, assets, Supabase schema, real Gemini endpoint, tests, hosted demo or PvP were created by this planning ZIP.
