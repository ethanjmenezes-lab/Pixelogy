# Codex implementation tasks and acceptance gates (v4)

**Rule:** complete and test each task before checking it. Do not claim that a Figma design, API, real leaderboard or multiplayer is connected unless proven. These are future tasks, not already implemented features.

## M0 — Governance & Figma source (P0)
- [ ] Check current HowdyHack rules and confirm implementation timing/user approval.
- [ ] Read every core spec in `README.md` and `AGENTS.md`.
- [ ] Create GitHub repo and configure Vercel deployment/API function target, Supabase public project details and server-side Gemini secret placement; do not expose keys.
- [ ] Create or obtain Figma file with priority mobile frames; record actual file/frame links if available (none bundled).
- [ ] Define semantic design tokens, named button/card/gear-slot/HP component variants and original red crab art plan; if no Figma access, document approximation from written spec.
- [ ] Establish project board and scope: MVP safe discovery + gear + CPU practice; optional cleanup XP, online features honest extras.
**Pass:** Codex can name design source, next milestone, and what doesn't yet exist.

## M1 — App and visual foundations (P0)
- [ ] Scaffold React + Vite + TypeScript + Tailwind + React Router, lint/test scripts, and Vercel serverless `api/` folder.
- [ ] Implement semantic palette/spacing, mobile bottom nav and responsive desktop nav using real Figma variables if provided.
- [ ] Create real routes `/`, `/scan`, `/collection`, `/workshop`, `/battle/practice`, `/leaderboard`.
- [ ] Create original red crab base art and transparent gear layer asset contract; don't import Pokémon/Prodigy assets.
**Pass:** routes/mobile nav render with a coherent pixel beach style; no fake interactive controls.

## M2 — Capture and safe consent (P0)
- [ ] Camera-compatible file upload, preview, retake, size/type validation, orientation correction and EXIF stripping.
- [ ] Show clear safety warning and ask separate consent before sending any photo to Gemini.
- [ ] Implement safe manual category/subtype selection, including all 9 original canonical categories.
**Pass:** phone image flows even with no camera permission or Gemini key; unsafe objects are not rewarded.

## M3 — Gemini + subject focus (core integration)
- [ ] Vercel serverless Gemini adapter; `npm run dev` does not serve `/api` unless a local proxy/emulator is configured. Test with `vercel dev` or explicitly configured equivalent; server-only and strict schema: label, category/subtype, `safety`, bbox, optional polygon.
- [ ] Validate bbox axes and polygons against normalized 0–1000 spec; portrait/landscape and malformed-response tests.
- [ ] Implement manual draggable crop regardless of AI availability; segmented mask optional when accurate.
- [ ] Never call cropping true transparent segmentation; clear manual/AI mode labels.
**Pass:** bottle on cluttered background yields a bottle-focused preview; missing credentials give honest manual path.

## M4 — Pixel discovery card + optional cleanup claim (P0)
- [ ] Render cropped object as pixel art (Canvas nearest-neighbor), framed on a beach background.
- [ ] Save a reviewed **safe discovery** card/gear with no disposal requirement. Hazardous/uncertain items block eligible gear/discovery; do not encourage handling.
- [ ] Offer optional one-time safe-disposal self-report, now or later; only that awards cleanup XP.
- [ ] Assign persisted cosmetic rarity from approved 60/27/10/3 distribution; fixed **cleanup-only** XP rules +10/+5; no XP on scan alone.
- [ ] Give recognized safe items a **deterministic** gear blueprint from catalog, not AI-determined power.
**Pass:** safe scan without disposal → exactly 1 card + 1 gear candidate and **0 cleanup XP**. One cleanup confirmation → +10 or +15 XP exactly once. Unsafe scan → no gear/reward.

## M5 — ShoreDex + storage (P0)
- [ ] IndexedDB stores pixel art, unique discovery cards, separately keyed cleanup events, cleanup XP, first-confirmed-cleanup category flags; no raw original photos.
- [ ] Idempotent discovery save and optional cleanup claim on double taps and retry; reload keeps cards, cosmetic rarity and XP.
- [ ] Show gear label, slot and art in collection; other safe litter can be card only.
**Pass:** cards survive reload, repeat scans create distinct collectible IDs, and optional cleanup of a repeated category does not earn an extra first-category bonus.

## M6 — Crab Workshop (P0)
- [ ] Implement five slots: Head, Shell, Main Claw, Off Claw, Feet.
- [ ] Gear catalog rules, wrong-slot rejection, ownership lookup, unique instance ID per slot, equip/swap/unequip.
- [ ] Render original red crab + layered overlays aligned with anchor metadata and card photo motif (where possible).
- [ ] Derive bounded HP/ATK/DEF/SPD from unique equipped blueprints; rarity cannot change stats.
- [ ] Persist loadout and show before/after stat changes.
**Pass:** bag=head, magazine=shell, bottle=weapon, can=shield, cap=feet visibly equip; same ID cannot fill two slots.

## M7 — Practice Battle: **fully playable** (P0)
- [ ] Pure `resolveTurn` reducer follows battle doc exactly.
- [ ] Speed-first turn order and fixed HP/ATK/DEF/SPD; Pinch, Guard, Tidal Slam + cooldown.
- [ ] CPU chooses valid moves and game reaches genuine win/lose; visible HP, combat log and replay.
- [ ] Mobile combat layout matches Figma when available; visual damage/guard feedback has reduced-motion alternative.
- [ ] No practice score as fake weekly cleanup XP or human leaderboard position.
**Pass:** user equips 1 item then finishes CPU fight; unit tests for damage, cooldown, guards and illegal actions pass.

## M8 — Real weekly leaderboard (core online target)
- [ ] Supabase guest identity, opt-in nickname, server-authoritative idempotent **self-reported cleanup** events (not mere scans), RLS and rate limits.
- [ ] Real weekly cleanup XP query with America/Chicago Monday boundary and cleanup count as tie-breaker.
- [ ] Clear `Live leaderboard unavailable` without credentials; no fake rankings.
**Pass:** two opted-in users actually submit and read separate server-backed rankings; tampered XP rejected.

## M9 — Online PvP challenge (stretch, cut if rushed)
- [ ] Two actual authenticated users, server-backed expiring invites, create/join/ready.
- [ ] Server-validated owned loadout snapshots, protected match state, atomic versioned turns.
- [ ] Idempotent move requests, no out-of-turn/unowned gear, genuine result visible to both players.
- [ ] Waiting/reconnect/forfeit/expiry states; no CPU opponent masquerading as player.
**Pass:** two separate browsers/accounts take turns to the same real winner; if not, hide PvP UI.

## M10 — QA, deploy and live demo
- [ ] Run typecheck, lint, unit tests, build and real phone smoke test; report actual outcomes.
- [ ] Check clean install, .env template, responsive views, keyboard/reduced-motion, image consent and safety.
- [ ] Test 3 complete scenarios in `DEMO_AND_TESTING.md` including battle workshop.
- [ ] Deploy HTTPS; add screenshots/media only after confirmed creation and licensing checks.
- [ ] Demo only what actually works; explicitly label manual Gemini fallback, CPU fights and unconfigured services.
**Pass:** judge sees end-to-end safe scan → discovery card → gear red crab → genuine Practice vs CPU; all public claims truthful.

## Resource triage

If the remaining time is short: **M1/M2/M4/M5/M6/M7 first**, with honest manual M3 fallback; then real M3 Gemini integration, then M8 leaderboard, then M9 PvP. Polish can be trimmed sooner than the essential interaction. Create no security-sensitive mock API presenting invented competitors.
